<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="five2" tilewidth="160" tileheight="192" tilecount="5" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../tiled/examples/sticker-knight/map/1.png" width="64" height="64"/>
 </tile>
 <tile id="1">
  <properties>
   <property name="rrmove" type="bool" value="true"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
  <image source="../tiled/examples/sticker-knight/map/2.png" width="64" height="64"/>
 </tile>
 <tile id="2">
  <image source="../tiled/examples/sticker-knight/map/3.png" width="64" height="64"/>
 </tile>
 <tile id="3">
  <properties>
   <property name="die" type="bool" value="true"/>
  </properties>
  <image source="../tiled/examples/sticker-knight/map/4.png" width="160" height="192"/>
 </tile>
 <tile id="4">
  <properties>
   <property name="death" type="bool" value="true"/>
   <property name="rmove" type="bool" value="true"/>
  </properties>
  <image source="../tiled/examples/sticker-knight/map/5.png" width="128" height="32"/>
 </tile>
</tileset>
