<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="444" tilewidth="1920" tileheight="2048" tilecount="64" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/alter - 副本.png" width="160" height="192"/>
 </tile>
 <tile id="1">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/alter.png" width="160" height="192"/>
 </tile>
 <tile id="2">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/backgroundArch.png" width="135" height="115"/>
 </tile>
 <tile id="3">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/backgroundMountain.png" width="380" height="140"/>
 </tile>
 <tile id="4">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/backgroundTower.png" width="129" height="332"/>
 </tile>
 <tile id="5">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/backgroundTree.png" width="109" height="177"/>
 </tile>
 <tile id="6">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/blobBlue.png" width="96" height="64"/>
 </tile>
 <tile id="7">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/blobGreen.png" width="96" height="64"/>
 </tile>
 <tile id="8">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/blue.png" width="64" height="64"/>
 </tile>
 <tile id="9">
  <properties>
   <property name="bomb2" type="bool" value="true"/>
  </properties>
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/bombStroked.png" width="96" height="128"/>
 </tile>
 <tile id="10">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/castleWall.png" width="64" height="64"/>
 </tile>
 <tile id="11">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/cloud.png" width="384" height="128"/>
 </tile>
 <tile id="12">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/column1.png" width="128" height="192"/>
 </tile>
 <tile id="13">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/column2.png" width="128" height="192"/>
 </tile>
 <tile id="14">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/doorBlueStroked.png" width="160" height="192"/>
 </tile>
 <tile id="15">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/doorGreenStroke.png" width="160" height="192"/>
 </tile>
 <tile id="16">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/doorRedStroked.png" width="160" height="192"/>
 </tile>
 <tile id="17">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/doorStroked.png" width="160" height="192"/>
 </tile>
 <tile id="18">
  <properties>
   <property name="move" type="bool" value="true"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/earthWall.png" width="64" height="64"/>
 </tile>
 <tile id="19">
  <properties>
   <property name="solid" type="bool" value="true"/>
  </properties>
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/earthWall2.png" width="64" height="64"/>
 </tile>
 <tile id="20">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/exit.png" width="160" height="192"/>
 </tile>
 <tile id="21">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/flare.png" width="192" height="192"/>
 </tile>
 <tile id="22">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/gemBlueStroked.png" width="64" height="64"/>
 </tile>
 <tile id="23">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/gemRedStroked.png" width="64" height="64"/>
 </tile>
 <tile id="24">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/grassLarge.png" width="224" height="32"/>
 </tile>
 <tile id="25">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/grassSmall.png" width="160" height="32"/>
 </tile>
 <tile id="26">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/grey.png" width="64" height="64"/>
 </tile>
 <tile id="27">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/hero.png" width="128" height="160"/>
 </tile>
 <tile id="28">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/keyGreenStroked.png" width="96" height="64"/>
 </tile>
 <tile id="29">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/keyRedStroked.png" width="96" height="64"/>
 </tile>
 <tile id="30">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/keyYellowStroked.png" width="96" height="64"/>
 </tile>
 <tile id="31">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/platform1.png" width="192" height="64"/>
 </tile>
 <tile id="32">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/platform2.png" width="192" height="64"/>
 </tile>
 <tile id="33">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/platform3.png" width="192" height="64"/>
 </tile>
 <tile id="34">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/platform4.png" width="192" height="64"/>
 </tile>
 <tile id="35">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/platformBase1.png" width="256" height="96"/>
 </tile>
 <tile id="36">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/platformBase2.png" width="256" height="96"/>
 </tile>
 <tile id="37">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/platformBase3.png" width="256" height="96"/>
 </tile>
 <tile id="38">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/platformBase4.png" width="256" height="96"/>
 </tile>
 <tile id="39">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/platformBlock1.png" width="128" height="96"/>
 </tile>
 <tile id="40">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/platformBlock2.png" width="128" height="96"/>
 </tile>
 <tile id="41">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/platformBlock3.png" width="128" height="96"/>
 </tile>
 <tile id="42">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/platformBlock4.png" width="128" height="96"/>
 </tile>
 <tile id="43">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/platformConnector1.png" width="96" height="64"/>
 </tile>
 <tile id="44">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/platformConnector2.png" width="96" height="64"/>
 </tile>
 <tile id="45">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/platformConnector3.png" width="96" height="64"/>
 </tile>
 <tile id="46">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/platformConnector4.png" width="96" height="64"/>
 </tile>
 <tile id="47">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/pushBlock1.png" width="96" height="96"/>
 </tile>
 <tile id="48">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/pushBlock2.png" width="96" height="96"/>
 </tile>
 <tile id="49">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/pushBlock3.png" width="96" height="96"/>
 </tile>
 <tile id="50">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/shadow.png" width="64" height="64"/>
 </tile>
 <tile id="51">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/shieldStroked.png" width="93" height="93"/>
 </tile>
 <tile id="52">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/sign.png" width="160" height="128"/>
 </tile>
 <tile id="53">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/skeleton.png" width="133" height="160"/>
 </tile>
 <tile id="54">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/sprites.png" width="1920" height="2048"/>
 </tile>
 <tile id="55">
  <properties>
   <property name="sword2" type="bool" value="true"/>
  </properties>
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/swordStroked.png" width="192" height="96"/>
 </tile>
 <tile id="56">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/torch.png" width="96" height="96"/>
 </tile>
 <tile id="57">
  <properties>
   <property name="death3" type="bool" value="true"/>
  </properties>
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/trap.png" width="128" height="32"/>
 </tile>
 <tile id="58">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/wallDecor1.png" width="128" height="96"/>
 </tile>
 <tile id="59">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/wallDecor2.png" width="128" height="96"/>
 </tile>
 <tile id="60">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/wallDecor3.png" width="160" height="128"/>
 </tile>
 <tile id="61">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/window1.png" width="65" height="64"/>
 </tile>
 <tile id="62">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/window2.png" width="64" height="64"/>
 </tile>
 <tile id="63">
  <image source="F:/下载/Tiled/Tiled/tiled/examples/sticker-knight/map/window3.png" width="56" height="59"/>
 </tile>
</tileset>
