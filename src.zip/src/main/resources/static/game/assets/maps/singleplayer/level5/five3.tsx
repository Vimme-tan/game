<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="five3" tilewidth="64" tileheight="64" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <properties>
   <property name="fake" type="bool" value="true"/>
  </properties>
  <image source="../tiled/examples/sticker-knight/map/2.png" width="64" height="64"/>
 </tile>
</tileset>
